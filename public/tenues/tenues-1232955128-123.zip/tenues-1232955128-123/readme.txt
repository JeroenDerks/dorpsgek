=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

 HollandseVelden iconset
	> http://www.hollandsevelden.nl/iconset/

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

De HollandseVelden iconset is een gratis set van 
meer dan 460 32x32-pixel iconen in PNG formaat. 
Dit alles is te downloaden voor de spectaculaire 
prijs van �0,00 per icoon!

Wij horen graag dat onze moeite niet voor niets 
is geweest. Mocht je de iconen zelf gebruiken of 
ergens op het internet tegenkomen, stuur ons dan 
een link of screenshot van de desbetreffende 
website! Deze iconset valt onder een 
Creative Commons Attribution 2.5 Licentie, wat 
betekent dat je de iconen overal voor kunt 
gebruiken en ze desgewenst mag aanpassen. Het 
enige wat wij ervoor terug vragen is een link 
naar deze website.


    * Creative Commons Attribution 2.5 Licentie
    	> http://creativecommons.org/licenses/by/2.5/


Okay, genoeg gepraat. Gebruik de onderstaande 
links om een overzicht van alle iconen te 
bekijken of om de hele set te downloaden:


    * Bekijk de Hollandsevelden iconset
    	> http://www.hollandsevelden.nl/downloads/HollandseVelden-iconset.png

    * Download de Hollandsevelden iconset
		> http://www.hollandsevelden.nl/downloads/HollandseVelden-iconset.zip


Bijna wekelijks voegen wij nieuwe iconen toe aan 
deze set. Mocht er toch nog een tenue zijn dat je 
mist, laat het ons de even weten! Stuur wel een 
link naar een foto mee waarop we kunnen zien hoe 
het shirt eruit moet komen te zien, en wij maken 
er zo snel mogelijk een icoon van!


    * Contact
		> http://www.hollandsevelden.nl/contact/
